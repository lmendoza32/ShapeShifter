package com.example.androidsafeshapeshifter

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var img = findViewById<ImageView>(R.id.imageView) as ImageView
        var boton = findViewById<Button>(R.id.button) as Button
        var bandera = 1
        boton.setOnClickListener {
            if(bandera == 0)
            {
                img.setImageResource(R.drawable.music)
                bandera = 1
            }else
            {
                img.setImageResource(R.drawable.android2)
                bandera = 0
            }
        }
    }
}